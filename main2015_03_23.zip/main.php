<?php
/**
 * Created by PhpStorm.
 * User: Mihail
 * Date: 17.03.2015
 * Time: 9:44
 */



require_once 'simple_html_dom.php';
//include 'simple_html_dom.php';
echo "<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\"/>
    <title>Главная</title>
</head>";
//echo "parse...</br>";
$name_of_the_departament = $_GET['kafedra'];
$name_of_the_teacher=$_GET['teacher'];
$number_of_the_week=$_GET['week'];

$name_of_the_departament_cp1251 = iconv("UTF-8", "CP1251", $name_of_the_departament);
$name_of_the_teacher_cp1251 = iconv("UTF-8", "CP1251", $name_of_the_teacher);

echo $name_of_the_departament." - ".$name_of_the_teacher." - ".$number_of_the_week;
echo "</br>-------------------</br>";

//$number_of_the_week = 2;
//$name_of_the_teacher = 'Жуковский В.С.';'

if ($name_of_the_departament!="" and $name_of_the_teacher=="" and $number_of_the_week=="" )
{
 //   echo $name_of_the_departament . "</br>";
//    echo $name_of_the_departament_cp1251 . "</br>";

    if ($curl = curl_init()) {
        curl_setopt($curl, CURLOPT_URL, 'http://miu.by/rus/schedule/schedule.php');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, 'kaf=' . $name_of_the_departament_cp1251);
        $out = curl_exec($curl);
   // echo $out;
        curl_close($curl);
    } else {
        echo "??";
    }
   // echo $out;

  //  echo "1---------</br>";
    $html = new simple_html_dom();
    $html = str_get_html($out);
    $input_block = $html->find("form");

    //  echo    $input_block[0];
    // echo $html = str_get_html($input_block[0]);
    // $html = str_get_html($input_block[0]);

//    echo "</br>-= Преподаватели =-</br>";
    $nodes = $input_block[2]->find("option");
    foreach ($nodes as $node) {
        $val = $node->value;
        if ($val!="")echo $val . "<br />";
        //echo $val . " , ";
    }


/*

echo "</br>!222!!</br>";

    $html = new simple_html_dom();
    $html = str_get_html($out);
    $nodes = $html->find("option");

    foreach ($nodes as $node) {
        $val = $node->value;
        echo $val . "<br />";
    }
*/

//освобождаем ресурсы
    $html->clear();
    unset($html);
}
elseif ($name_of_the_departament!="" and $name_of_the_teacher!="" and $number_of_the_week=="" ) {

echo $name_of_the_teacher. "!!!!</br>";

    echo $name_of_the_departament_cp1251 . "</br>";
    echo $name_of_the_teacher_cp1251 . "</br>";

    if ($curl = curl_init()) {
        curl_setopt($curl, CURLOPT_URL, 'http://miu.by/rus/schedule/schedule.php');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, 'kaf=' . $name_of_the_departament_cp1251 . '&fio=' . $name_of_the_teacher_cp1251);
        $out = curl_exec($curl);
// echo $out;
        curl_close($curl);

        $html = new simple_html_dom();
        $html = str_get_html($out);
        $nodes = $html->find("option");

        foreach ($nodes as $node) {
            $val = $node->value;
            echo $val . "<br />";
        }
//освобождаем ресурсы
        $html->clear();
        unset($html);


    }
} elseif ($name_of_the_departament!="" and $name_of_the_teacher!="" and $number_of_the_week!="" )
{

//    echo $name_of_the_departament_cp1251 . "</br>";
//    echo $name_of_the_teacher_cp1251 . "</br>";
//    echo $number_of_the_week . "</br>";

    if ($curl = curl_init()) {
        curl_setopt($curl, CURLOPT_URL, 'http://miu.by/rus/schedule/schedule.php');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        //  curl_setopt($curl, CURLOPT_POSTFIELDS, 'kaf='.$name_of_the_departament_cp1251.'&fio='.$name_of_the_teacher_cp1251.'&g_f='.$number_of_the_week);
        curl_setopt($curl, CURLOPT_POSTFIELDS, 'kaf=' . $name_of_the_departament_cp1251 . '&fio=' . $name_of_the_teacher_cp1251 . '&week=' . $number_of_the_week);
        $out = curl_exec($curl);
    //    echo $out;
  //    echo   $out_cp1251 = iconv("CP1251","UTF-8", $out);
        curl_close($curl);

        $html = new simple_html_dom();
        $html = str_get_html($out);
        $table = $html->find('table',9);

// все в кучу
//echo  $table->innertext;

        echo "</br>2--------</br>";


        echo  $table;

        echo "</br>3--------</br>";

        $rowData = array();

        foreach($table->find('tr') as $row) {
            // initialize array to store the cell data from each row
            $flight = array();
            foreach($row->find('td') as $cell) {
                // push the cell's text to the array
                $flight[] = $cell->plaintext;
            }
            $rowData[] = $flight;
        }

        echo '<table border=\"1\">';
        foreach ($rowData as $row => $tr) {
            echo '<tr>';
            foreach ($tr as $td)
                echo '<td>' . $td .'</td>';
            echo '</tr>';
        }
        echo '</table>';









    }
}
else
{

///// УДАЛИТЬ
    echo "End! Конец</br>";
    exit;

}
?>



