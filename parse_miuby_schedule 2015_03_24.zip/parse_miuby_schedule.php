﻿<?php
/**
 * Created by PhpStorm.
 * User: Mihail
 * Date: 17.03.2015
 * Time: 9:44
 */


require_once 'simple_html_dom.php';
/*
echo "<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\"/>
    <title>Главная</title>
</head>";
*/
$name_of_the_departament = $_GET['kafedra'];
$list_name_of_the_departament = $_GET['list_kafedra'];
$name_of_the_teacher = $_GET['teacher'];
$number_of_the_week = $_GET['week'];
$format_of_the_week = $_GET['weekf'];
$name_of_the_specialty = $_GET['specialty'];
$number_of_the_group = $_GET['group'];
$number_of_the_week_now = $_GET['weekn'];


$name_of_the_departament_cp1251 = iconv("UTF-8", "CP1251", $name_of_the_departament);
$name_of_the_teacher_cp1251 = iconv("UTF-8", "CP1251", $name_of_the_teacher);
$name_of_the_speciality_cp1251 = iconv("UTF-8", "CP1251", $name_of_the_specialty);
$number_of_the_group_cp1251 = iconv("UTF-8", "CP1251", $number_of_the_group);

//echo $name_of_the_departament." - ".$name_of_the_teacher." - ".$number_of_the_week;
//echo "</br>-------------------</br>";

if ($name_of_the_departament != "" and $name_of_the_teacher == "" and $number_of_the_week == "") {
    if ($curl = curl_init()) {
        curl_setopt($curl, CURLOPT_URL, 'http://miu.by/rus/schedule/schedule.php');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, 'kaf=' . $name_of_the_departament_cp1251);
        $out = curl_exec($curl);
        curl_close($curl);
    } else {
        echo "error";
    }

    $html = new simple_html_dom();
    $html = str_get_html($out);
    $input_block = $html->find("form");

    $nodes = $input_block[2]->find("option");
    foreach ($nodes as $node) {
        $val = $node->value;
        if ($val != "") echo $val . "<br />";
    }

    $html->clear();
    unset($html);

} elseif ($name_of_the_departament != "" and $name_of_the_teacher != "" and $number_of_the_week == "") {

    if ($curl = curl_init()) {
        curl_setopt($curl, CURLOPT_URL, 'http://miu.by/rus/schedule/schedule.php');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, 'kaf=' . $name_of_the_departament_cp1251 . '&fio=' . $name_of_the_teacher_cp1251);
        $out = curl_exec($curl);
        curl_close($curl);

// Номера неделей
        $out_utf8 = iconv("CP1251", "UTF-8", $out);

        $html = new simple_html_dom();
        $html = str_get_html($out_utf8);
        $input_block = $html->find("form");

        $nodes = $input_block[3]->find("option");
        foreach ($nodes as $node) {
            //$val = $node->value;
            //$val = $node->innertext;
            $val = $node->plaintext;
            if ($val != "") echo $val . "<br>";
        }
        $html->clear();
        unset($html);
    }
} elseif ($name_of_the_departament != "" and $name_of_the_teacher != "" and $number_of_the_week != "") {

    if ($curl = curl_init()) {
        curl_setopt($curl, CURLOPT_URL, 'http://miu.by/rus/schedule/schedule.php');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, 'kaf=' . $name_of_the_departament_cp1251 . '&fio=' . $name_of_the_teacher_cp1251 . '&week=' . $number_of_the_week);
        $out = curl_exec($curl);

        curl_close($curl);

        $html = new simple_html_dom();
        $html = str_get_html($out);
        $table = $html->find('table', 9);

        if ($format_of_the_week == 0) {
            //  echo "</br>2--------</br>";
            echo $table;
            //   echo "</br>3--------</br>";
            $rowData = array();
        } else {
            foreach ($table->find('tr') as $row) {
                $flight = array();
                foreach ($row->find('td') as $cell) {
                    $flight[] = $cell->plaintext;
                }
                $rowData[] = $flight;
            }

            echo '<table border=\"1\">';
            foreach ($rowData as $row => $tr) {
                echo '<tr>';
                foreach ($tr as $td)
                    echo '<td>' . $td . '</td>';
                echo '</tr>';
            }
            echo '</table>';
        }
    }
} elseif ($name_of_the_specialty != "" and $number_of_the_group == "") {
//      echo $name_of_the_specialty;

    if ($curl = curl_init()) {
        curl_setopt($curl, CURLOPT_URL, 'http://miu.by/rus/schedule/schedule.php');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, 'spec=' . $name_of_the_speciality_cp1251);
        $out = curl_exec($curl);
        curl_close($curl);
    } else {
        echo "error";
    }

    //Получаем номера групп по данной специальности
    $html = new simple_html_dom();
    $html = str_get_html($out);
    $input_block = $html->find("form");

    $nodes = $input_block[2]->find("option");
    foreach ($nodes as $node) {
        $val = $node->value;
        if ($val != "") echo $val . "<br />";
    }

    $html->clear();
    unset($html);

} elseif ($name_of_the_specialty != "" and $number_of_the_group != "" and $number_of_the_week == "") {
    //  echo $number_of_the_group;

    if ($curl = curl_init()) {
        curl_setopt($curl, CURLOPT_URL, 'http://miu.by/rus/schedule/schedule.php');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, 'spec=' . $name_of_the_speciality_cp1251 . '&group=' . $number_of_the_group_cp1251);
        $out = curl_exec($curl);
        curl_close($curl);
    } else {
        echo "error";
    }

    //Получаем номера недель для группы
    $out_utf8 = iconv("CP1251", "UTF-8", $out);

    $html = new simple_html_dom();
    $html = str_get_html($out_utf8);
    $input_block = $html->find("form");

    $nodes = $input_block[3]->find("option");
    foreach ($nodes as $node) {
        //$val = $node->value;
        //$val = $node->innertext;
        $val = $node->plaintext;
        if ($val != "") echo $val . "<br>";
    }
    $html->clear();
    unset($html);
} elseif ($name_of_the_specialty != "" and $number_of_the_group != "" and $number_of_the_week != "") {
    //  echo $number_of_the_group;

    if ($curl = curl_init()) {
        curl_setopt($curl, CURLOPT_URL, 'http://miu.by/rus/schedule/schedule.php');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, 'spec=' . $name_of_the_speciality_cp1251 . '&group=' . $number_of_the_group_cp1251 . '&week=' . $number_of_the_week);
        $out = curl_exec($curl);
        curl_close($curl);
    } else {
        echo "error";
    }
    if ($out == "") {
        echo "error";
        exit;
    }

    $flag_error = 0;
    $html = new simple_html_dom();
    $html = str_get_html($out);
    $table = $html->find('table', 9);

    // if ($table=="<table style='border-collapse:collapse;width:100%;border:solid #999 1px;'> </table>");
    //  if ($table->plaintext=="");
    // {echo "error";
    //     exit;
    //  }

    if ($format_of_the_week == 0) {
        //  echo "</br>2--------</br>";
        echo $table;
        //   echo "</br>3--------</br>";
    } else {
        //echo "</br>2--------</br>";
        //    echo $table;
        //   echo "</br>2--------</br>";
        $rowData = array();
        foreach ($table->find('tr') as $row) {
            $flight = array();
            foreach ($row->find('td') as $cell) {
                $flight[] = $cell->plaintext;
            }
            $rowData[] = $flight;
        }

        echo '<table border=\"1\">';
        foreach ($rowData as $row => $tr) {
            echo '<tr>';
            foreach ($tr as $td)
                echo '<td>' . $td . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    }

} elseif ($number_of_the_week_now == 1) {

    if ($curl = curl_init()) {
        curl_setopt($curl, CURLOPT_URL, 'http://miu.by/rus/schedule/schedule.php');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        //    curl_setopt($curl, CURLOPT_POSTFIELDS, 'kaf=' . $name_of_the_departament_cp1251);
        $out = curl_exec($curl);
        curl_close($curl);
    } else {
        echo "error";
    }

    $html = new simple_html_dom();
    $html = str_get_html($out);
    $input_block = $html->find("form");

    $nodes = $input_block[0]->find("option");
    $cont1 = 0;
    foreach ($nodes as $node) {
        $cont1++;
        $val = $node->value;
        //     if ($val != "") echo $val . "<br />";
    }

    $html->clear();
    unset($html);

//    echo "$cont1<br>";

    echo $cc = count($nodes);
    //   echo "<br> - ".$nodes[2];


} elseif ($list_name_of_the_departament == 1) {

    if ($curl = curl_init()) {
        curl_setopt($curl, CURLOPT_URL, 'http://miu.by/rus/schedule/schedule.php');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        //       curl_setopt($curl, CURLOPT_POSTFIELDS, 'kaf=' . $name_of_the_departament_cp1251);
        $out = curl_exec($curl);
        curl_close($curl);
    } else {
        echo "error";
    }

    $html = new simple_html_dom();
    $html = str_get_html($out);
    $input_block = $html->find("form");

    $nodes = $input_block[2]->find("option");
    foreach ($nodes as $node) {
        $val = $node->value;
        if ($val != "") echo $val . "<br />";
    }

    $html->clear();
    unset($html);

} else {
    echo "error";
}
?>